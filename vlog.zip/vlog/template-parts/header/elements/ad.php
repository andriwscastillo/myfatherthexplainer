<?php if( $ad = vlog_get_option('ad_header') ): ?>
	<div class="vlog-ad hidden-xs"><?php echo do_shortcode( $ad ); ?></div>
<?php endif; ?>