<nav class="vlog-pagination">
	
	<div class="vlog-prev">
		<?php previous_posts_link( __vlog( 'newer_entries' ) ); ?>
	</div>

	<div class="vlog-next">
		<?php next_posts_link( __vlog( 'older_entries' ) ); ?>
	</div>

</nav>